
package left_roy;
import java.util.Scanner;
public class Left_roy {
    public static void main(String[] args) {
        int i,j,k=1;
        String ABC="QWERTYUIOPASDFGHJKLZXCVBNM";
        String input;
        String first;
        String A = null;
        Scanner sc = new Scanner (System.in);
        first =sc.nextLine();
        System.out.println("->");
        input = sc.nextLine();
        int inl=input.length();
        for(i=0;k<=inl;i++)
        {
           A = input.substring(i, k);
           k++;
                 System.out.println(A);
        }
         
        
    }
    
}
