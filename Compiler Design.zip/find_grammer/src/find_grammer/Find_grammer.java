
package find_grammer;
import java.util.Scanner;
public class Find_grammer {
    public static void main(String[] args) {
        String input;
        int i, j = 5, k = 7, cf = 1;
        Scanner sc = new Scanner(System.in);
        System.out.println("INPUT A STRING WITHOUT SPACE");
        input = sc.nextLine();
        String G1 = "ababb";
        String G2 = "ababba€";
        String G3 = "ababbab";
        int inpl = input.length();

        if (inpl < 5) {
            System.out.println("input 5 or more for find the grammer");
        }

        if (input.equals("ababb")) {
            cf--;
            System.out.println("The input hits the 1ST Grammer i)(a|b)*abb ");
        }
        if (input.equals("ababba€")) {
            cf--;
            System.out.println("The input hit a match with the 2ND Grammer ii)(a|b)*abb(a|€)+");
        }
        if (input.equals("ababbab")) {
            cf--;
            System.out.println("The input hit a match with the 3RD Grammer   iii)(a|b)+abb(a|b)+");
        }
        for (i = 0; j <= inpl; i++) {
            String G1M = input.substring(i, j);
            j++;
            if (G1.equals(G1M)) {
                System.out.println("The input hits the 1st Grammer i)(a|b)*abb ");
                cf--;
            }
        }
        for (i = 0; k <= inpl; i++) {
            String G23M = input.substring(i, k);
            k++;
            if (G2.equals(G23M)) {
                System.out.println("The input hit a match with the 2ND Grammer ii)(a|b)*abb(a|€)+");
                cf--;
            }
            if (G3.equals(G23M)) {
                System.out.println("The input hit a match with the 3RD Grammer   iii)(a|b)+abb(a|b)+");
                cf--;
            }

        }
        if (cf == 1) {
            System.out.println("This input does not match any grammer ");
        }

    }

}
