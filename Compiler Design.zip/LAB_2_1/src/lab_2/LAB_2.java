/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package LAB_2;

import java.util.Scanner;

class Lexical_Analyze {

    String Point = ".";
    String powS = "^", exS = "E";
    int cf = 1, point = 0, pow = 0, ex = 0;

    void Find_Identifier(String s, String Character, String Digit) {
        for (int i = 1; i < s.length(); i++) {
            if (Character.indexOf((s.charAt(i))) >= 0 || Digit.indexOf((s.charAt(i))) >= 0) {
                cf = 0;
            } else {
                cf = 1;
                break;
            }
        }
        if (cf == 0) {
            System.out.println(s + " IS AN IDENTIFIER");
        } else if (cf == 1) {
            System.out.println(s + " IS NOT AN IDENTIFIER");
        }
    }

    void Find_Integer(String s, String Digit) {
        for (int i = 1; i < s.length(); i++) {
            if (Digit.indexOf((s.charAt(i))) >= 0) {
                cf = 0;
            } else {
                cf = 1;
                break;
            }
        }
        if (cf == 0) {
            System.out.println(s + " IS AN INTEGER");
        } else if (cf == 1) {
            System.out.println(s + " IS NAT AN INTEGER");
        }

    }

    void Find_Float(String s, String Digit) {

        for (int i = 1; i < s.length(); i++) {
            if (Digit.indexOf((s.charAt(i))) >= 0) {
                cf = 0;
            } else if (Point.indexOf((s.charAt(i))) >= 0) {
                ++point;
            } else {
                cf = 1;
                break;
            }
        }
        if (cf == 0 && point == 1) {
            System.out.println(s + " IS A FLOAT");
            point = 0;
        } else {
            System.out.println(s + " IS NOT A FLOAT");
        }
    }

    void Find_Power(String s, String Digit) {

        for (int i = 1; i < s.length(); i++) {
            if (Digit.indexOf((s.charAt(i))) >= 0) {
                cf = 0;
            } else if (powS.indexOf((s.charAt(i))) >= 0) {
                ++pow;
            } else {
                cf = 1;
                break;

            }
        }

        if (cf == 0 && pow == 1) {
            System.out.println(s + " IS A POWER NUMBER");
            pow = 0;
        } else {
            System.out.println(s + " IS NOT A POWER NUMBER");
        }

    }

    void Find_Exp(String s, String Digit) {

        for (int i = 1; i < s.length(); i++) {
            if (Digit.indexOf((s.charAt(i))) >= 0) {
                cf = 0;
            } else if (exS.indexOf((s.charAt(i))) >= 0) {
                ++ex;
            } else {
                cf = 1;
                break;

            }
        }

        if (cf == 0 && ex == 1) {
            System.out.println(s + "  IS NOT A EXPOENTIAL NUMBER");
            ex = 0;
        } else {
            System.out.println(s + "  IS A EXPOENTIAL NUMBER");
        }
    }
}

public class LAB_2 {

    public static void main(String[] args) {
        String sc, inputS;
        System.out.println("Please Input for identifer,integer,float: ");
        Scanner in = new Scanner(System.in);
        inputS = in.nextLine();
        String dot =".";
        String semi=";";
        String clone=":";
        String and="&";
        String plus="+";
        String min="-";
        String div="/";
        String mul="*";
        String per="%";
        String not= "!";
        String lp="(";
        String rp=")";
        
        String ALPHABET = "_aAbBcCdDeEfFgGhHiIj"
                + "JkKlLmMnNoOpPqQrRsS"
                + "tTuUvVwWxXyYzZ";
        String DIGIT = "1234567890";
        
        Lexical_Analyze LE = new Lexical_Analyze();
        while (!inputS.isEmpty()) {
            if (inputS.indexOf(' ') >= 0) {
                sc = inputS.substring(0, (inputS.indexOf(' ')));
                inputS = inputS.substring((inputS.indexOf(' ')) + 1, inputS.length());
            } else {
                sc = inputS.substring(0, (inputS.length()));
                inputS = "";
            }
            if (ALPHABET.indexOf((sc.charAt(0))) >= 0) {
                LE.Find_Identifier(sc, ALPHABET, DIGIT);
            } else if (DIGIT.indexOf((sc.charAt(0))) >= 0 && 
                    sc.indexOf('.') < 0 && sc.indexOf('^') < 0 && sc.indexOf('e') < 0 && sc.indexOf('E') < 0) {
                LE.Find_Integer(sc, DIGIT);
            }else if (dot.indexOf((sc.charAt(0))) >= 0){
                System.out.println(sc+" IS A DOT SIGN");
            } 
            else if (sc.indexOf('.') >= 0 &&
                    DIGIT.indexOf((sc.charAt(0))) >= 0) {
                LE.Find_Float(sc, DIGIT);
            } else if (sc.indexOf('^') >= 0 && DIGIT.indexOf((sc.charAt(0))) >= 0 &&
                    sc.indexOf('e') < 0 && sc.indexOf('E') < 0) {
                LE.Find_Power(sc, DIGIT);
            } else if (DIGIT.indexOf((sc.charAt(0))) >= 0 && (sc.indexOf('E') >= 0)) {
                LE.Find_Exp(sc, DIGIT);
            }
            

        }

    }
}
